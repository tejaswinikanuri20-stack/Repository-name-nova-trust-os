const state = {
  scenario: 'baseline',
  cart: [],
  selectedOrder: null,
  inventory: [
    { id:1, store:'GreenBasket Indiranagar', sku:'Amul Taaza 1L', onHand:8, verified:'18 min ago', hours:0.3, demand:'High', confidence:94, status:'fresh', icon:'🥛' },
    { id:2, store:'Sri Lakshmi Pharmacy', sku:'Crocin 500mg', onHand:3, verified:'2h ago', hours:2, demand:'Medium', confidence:78, status:'risk', icon:'💊' },
    { id:3, store:'Corner Mart Koramangala', sku:'Aashirvaad Atta 5kg', onHand:0, verified:'31h ago', hours:31, demand:'High', confidence:31, status:'risk', icon:'🌾' },
    { id:4, store:'Bakehouse HSR', sku:'Brown Bread', onHand:6, verified:'41 min ago', hours:0.7, demand:'Medium', confidence:91, status:'fresh', icon:'🍞' },
    { id:5, store:'Daily Needs Jayanagar', sku:'Dettol Handwash', onHand:2, verified:'6h ago', hours:6, demand:'High', confidence:57, status:'risk', icon:'🧴' },
    { id:6, store:'City Stationery', sku:'A4 Notebook', onHand:24, verified:'13 min ago', hours:0.2, demand:'Low', confidence:98, status:'fresh', icon:'📓' },
  ],
  orders: [
    { id:'NC-4821', store:'Corner Mart Koramangala', item:'Aashirvaad Atta 5kg', value:612, score:88, level:'high', status:'Action required', eta:'41–49 min', reasons:['Inventory not verified for 31h','High current demand','Store rejection rate elevated'], action:'verify' },
    { id:'NC-4819', store:'Sri Lakshmi Pharmacy', item:'Crocin 500mg + toiletries', value:428, score:64, level:'medium', status:'Watch', eta:'32–38 min', reasons:['Inventory verified 2h ago','One item has low stock','Peak period'], action:'verify' },
    { id:'NC-4812', store:'GreenBasket Indiranagar', item:'Milk + staples', value:754, score:21, level:'low', status:'Stable', eta:'24–29 min', reasons:['Inventory recently verified','Strong store acceptance history','High route reliability'], action:'none' },
    { id:'NC-4807', store:'Daily Needs Jayanagar', item:'Handwash + snacks', value:516, score:57, level:'medium', status:'Watch', eta:'29–37 min', reasons:['Low-stock SKU','Delivery partner availability moderate'], action:'substitute' },
  ],
  products: [
    {id:1, name:'Amul Taaza 1L', store:'GreenBasket Indiranagar', price:68, eta:'24–29 min', confidence:94, icon:'🥛', fallback:'Amul Gold 1L'},
    {id:2, name:'Brown Bread', store:'Bakehouse HSR', price:52, eta:'26–31 min', confidence:91, icon:'🍞', fallback:'Multigrain Bread'},
    {id:3, name:'Dettol Handwash 250ml', store:'Daily Needs Jayanagar', price:99, eta:'29–37 min', confidence:57, icon:'🧴', fallback:'Lifebuoy Handwash'},
    {id:4, name:'A4 Spiral Notebook', store:'City Stationery', price:85, eta:'22–27 min', confidence:98, icon:'📓', fallback:'A4 Ruled Notebook'},
  ]
};

const $ = (id) => document.getElementById(id);
const money = n => '₹' + Number(n).toLocaleString('en-IN');

function showToast(msg){
  const el = $('toast'); el.textContent = msg; el.classList.add('show');
  clearTimeout(window.toastTimer); window.toastTimer = setTimeout(()=>el.classList.remove('show'), 2300);
}

function setTab(tab){
  document.querySelectorAll('.tab').forEach(t=>t.classList.remove('active'));
  document.querySelectorAll('.nav-item').forEach(n=>n.classList.remove('active'));
  $('tab-'+tab).classList.add('active');
  document.querySelector(`[data-tab="${tab}"]`).classList.add('active');
  window.scrollTo({top:0, behavior:'smooth'});
  if(tab==='orders') renderOrders();
  if(tab==='inventory') renderInventory();
  if(tab==='customer') renderProducts();
}

document.querySelectorAll('.nav-item').forEach(btn => btn.addEventListener('click', ()=>setTab(btn.dataset.tab)));

document.querySelectorAll('.filter-btn').forEach(btn=>btn.addEventListener('click', ()=>{
  document.querySelectorAll('.filter-btn').forEach(b=>b.classList.remove('active'));
  btn.classList.add('active');
  renderInventory(btn.dataset.filter);
}));

function renderPriority(){
  const list = $('priorityList');
  list.innerHTML = state.orders.filter(o=>o.level!=='low').map(o=>`<div class="priority-item"><div class="risk-bar ${o.level}"></div><div><strong>${o.id} • ${o.item}</strong><small>${o.store} • risk ${o.score}/100</small></div><button class="secondary-btn" onclick="openOrder('${o.id}')">Inspect</button></div>`).join('');
  $('riskCount').textContent = state.orders.filter(o=>o.level!=='low').length + ' at risk';
}

function renderInventory(filter='all'){
  const q = ($('inventorySearch')?.value || '').toLowerCase();
  const rows = state.inventory.filter(x => {
    const matchesFilter = filter==='all' || x.status===filter;
    const matchesSearch = !q || `${x.store} ${x.sku}`.toLowerCase().includes(q);
    return matchesFilter && matchesSearch;
  });
  $('inventoryTable').innerHTML = rows.map(x=>{
    const fillClass = x.confidence >= 80 ? 'high-fill' : x.confidence >= 60 ? 'medium-fill' : 'low-fill';
    return `<tr>
      <td><span class="cell-main">${x.icon} ${x.sku}</span><span class="cell-sub">${x.store}</span></td>
      <td>${x.onHand}</td>
      <td>${x.verified}</td>
      <td>${x.demand}</td>
      <td class="confidence"><div class="confidence-line"><div class="${fillClass}" style="width:${x.confidence}%"></div></div><div class="confidence-text">${x.confidence}% confidence</div></td>
      <td><button class="secondary-btn" onclick="verifySku(${x.id})">${x.confidence<80?'Quick verify':'Refresh'}</button></td>
    </tr>`;
  }).join('');
  const high = Math.round(state.inventory.filter(x=>x.confidence>=80).length / state.inventory.length * 100);
  $('highConfidence').textContent = high + '%';
  $('staleCount').textContent = state.inventory.filter(x=>x.hours>24).length;
  $('riskySkuCount').textContent = state.inventory.filter(x=>x.confidence<80).length;
}

function verifySku(id){
  const x = state.inventory.find(i=>i.id===id); if(!x) return;
  x.confidence = Math.min(99, x.confidence + 22);
  x.hours = 0.05;
  x.verified = 'just now';
  x.status = 'fresh';
  if(x.onHand===0 && x.sku.includes('Atta')) x.onHand = 2;
  showToast(`${x.sku} verified — customer promise refreshed.`);
  renderInventory(document.querySelector('.filter-btn.active')?.dataset.filter || 'all');
  reScoreOrders();
}

$('verifyAllBtn').addEventListener('click', ()=>{
  state.inventory.filter(x=>x.confidence<80).forEach(x=>verifySku(x.id));
  state.scenario = 'verified priority SKUs';
  $('lastRun').textContent = 'Scenario: priority SKUs verified';
  showToast('Priority inventory verified. Risk scores recalculated.');
});
$('inventorySearch').addEventListener('input', ()=>renderInventory(document.querySelector('.filter-btn.active')?.dataset.filter || 'all'));

function reScoreOrders(){
  state.orders.forEach(o=>{
    const inv = state.inventory.find(x=>o.item.toLowerCase().includes(x.sku.toLowerCase().split(' ')[0].toLowerCase()) || x.sku.toLowerCase().includes(o.item.toLowerCase().split(' ')[0].toLowerCase()));
    if(inv && inv.confidence>=80){ o.score = Math.max(12, o.score-32); o.level='low'; o.status='Stable'; o.action='none'; }
  });
  renderPriority(); renderOrders(); updateDashboardMetrics();
}

function renderOrders(){
  $('orderList').innerHTML = state.orders.map(o=>`<div class="order-card ${state.selectedOrder===o.id?'selected':''}" onclick="openOrder('${o.id}')">
    <div class="risk-bar ${o.level}"></div><div><strong>${o.id}</strong><p>${o.item} • ${o.store}</p><span class="order-status status-${o.level==='low'?'stable':o.level==='medium'?'watch':'risk'}">${o.status}</span></div><div class="order-right"><strong>${money(o.value)}</strong><small>risk ${o.score}/100</small></div>
  </div>`).join('');
  if(state.selectedOrder) inspectOrder(state.selectedOrder);
}

function openOrder(id){ state.selectedOrder=id; setTab('orders'); inspectOrder(id); }
function inspectOrder(id){
  const o = state.orders.find(x=>x.id===id); if(!o) return;
  $('orderInspector').innerHTML = `<div class="panel-head"><div><h2>${o.id}</h2><p>${o.item}</p></div><span class="order-status status-${o.level==='low'?'stable':o.level==='medium'?'watch':'risk'}">${o.status}</span></div>
    <div class="risk-score"><strong>${o.score}</strong><div><div style="font-size:10px;color:#7b857e">Cancellation risk</div><div style="width:180px;margin-top:7px" class="risk-meter"><div style="width:${o.score}%;background:${o.level==='high'?'var(--danger)':o.level==='medium'?'var(--warn)':'var(--ok)'}"></div></div></div></div>
    ${o.reasons.map((r,i)=>`<div class="insight"><strong>Signal ${i+1}</strong><p>${r}</p></div>`).join('')}
    <div class="action-grid">${o.level!=='low'?`<button class="primary-btn" onclick="orderAction('${id}','verify')">Verify inventory</button><button class="secondary-btn" onclick="orderAction('${id}','substitute')">Suggest substitute</button><button class="secondary-btn" onclick="orderAction('${id}','reroute')">Reroute store</button><button class="secondary-btn" onclick="orderAction('${id}','accept')">Accept with promise</button>`:`<button class="primary-btn" onclick="orderAction('${id}','accept')">Accept with promise</button><button class="secondary-btn" onclick="showToast('Order already passes reliability checks.')">View proof</button>`}</div>`;
}

function orderAction(id, action){
  const o = state.orders.find(x=>x.id===id); if(!o) return;
  if(action==='verify'){
    const inv = state.inventory.find(x=>o.item.toLowerCase().includes(x.sku.toLowerCase().split(' ')[0].toLowerCase()) || x.store===o.store);
    if(inv) verifySku(inv.id);
    o.score = Math.max(10, o.score-35); o.level='low'; o.status='Inventory verified'; o.action='none';
    showToast(`${id}: inventory verified and risk reduced.`);
  }
  if(action==='substitute'){ o.score=Math.max(20,o.score-18); o.level='medium'; o.status='Substitute proposed'; o.action='substitute'; showToast(`${id}: customer-safe substitute proposed.`); }
  if(action==='reroute'){ o.score=Math.max(18,o.score-22); o.level='low'; o.status='Rerouted to reliable store'; o.action='none'; showToast(`${id}: order rerouted before cancellation.`); }
  if(action==='accept'){ o.score=Math.max(6,o.score-8); o.level='low'; o.status='Accepted with promise'; showToast(`${id}: promise accepted.`); }
  renderOrders(); renderPriority(); updateDashboardMetrics();
}

function renderProducts(){
  $('productGrid').innerHTML = state.products.map(p=>`<article class="product"><div class="product-top">${p.icon}</div><div class="product-body"><strong>${p.name}</strong><p>${p.store} • ${p.eta}</p><span class="confidence-pill">● ${p.confidence}% stock confidence</span><div class="product-foot"><span class="price">${money(p.price)}</span><button class="add-btn" onclick="addToCart(${p.id})">Add</button></div></div></article>`).join('');
}
function addToCart(id){
  const p = state.products.find(x=>x.id===id); if(!p) return;
  if(!state.cart.find(x=>x.id===id)) state.cart.push(p);
  $('cartText').textContent = state.cart.map(x=>x.name).join(' + ');
  $('cartSubtext').textContent = `${state.cart.length} item${state.cart.length>1?'s':''} • Promise engine found verified availability.`;
  $('checkoutBtn').disabled = false;
  showToast(`${p.name} added with ${p.confidence}% stock confidence.`);
}
$('checkoutBtn').addEventListener('click', ()=>{
  if(!state.cart.length) return;
  const avgEta = state.cart[0].eta;
  $('modalEta').textContent = avgEta;
  $('modalFallback').textContent = state.cart[0].fallback;
  $('checkoutMessage').textContent = `NOVA CART is accepting the order because the selected item has a verified availability signal. If stock changes before picking, the customer receives a substitute choice before the order fails.`;
  $('checkoutModal').classList.add('show');
});
$('closeModal').addEventListener('click', ()=>$('checkoutModal').classList.remove('show'));
$('placeOrderBtn').addEventListener('click', ()=>{ $('checkoutModal').classList.remove('show'); showToast('Demo order placed — reliability event logged.'); });
$('simulateBtn').addEventListener('click', ()=>{
  state.scenario = 'reliability simulation';
  state.inventory.filter(x=>x.confidence<80).forEach(x=>{ x.confidence=Math.min(98,x.confidence+15); x.verified='just now'; x.hours=0.05; x.status='fresh'; });
  state.orders.forEach(o=>{ if(o.level==='high'){o.score=Math.max(20,o.score-38);o.level='medium';o.status='Intervention applied';} else if(o.level==='medium'){o.score=Math.max(10,o.score-25);o.level='low';o.status='Stable after intervention';} });
  $('lastRun').textContent='Scenario: reliability simulation';
  renderInventory(); renderOrders(); renderPriority(); updateDashboardMetrics();
  showToast('Simulation complete: inventory confidence and order reliability improved.');
});

function updateDashboardMetrics(){
  const high = state.inventory.filter(x=>x.confidence>=80).length / state.inventory.length;
  const activeRisk = state.orders.filter(x=>x.level==='high').length;
  const med = state.orders.filter(x=>x.level==='medium').length;
  $('metricCancel').textContent = (11 - Math.min(4, activeRisk*1.2 + Math.max(0, 2-med*.4))).toFixed(1)+'%';
  $('metricRepeat').textContent = (27 + Math.min(6, (1-high)*-10 + (state.scenario!=='baseline'?4:0))).toFixed(0)+'%';
  $('metricDelivery').textContent = (37 - (state.scenario!=='baseline'?4:0))+'m';
  $('metricTickets').textContent = Math.round(5900 - (state.scenario!=='baseline'?720:0)).toLocaleString('en-IN');
}

function recalcImpact(){
  const orders = Number($('ordersInput').value)||38500;
  const cancel = Number($('cancelInput').value)||11;
  const reduction = Number($('reductionInput').value)||0;
  const aov = Number($('aovInput').value)||486;
  const tickets = Number($('ticketsInput').value)||5900;
  const ticketReduction = Number($('ticketReductionInput').value)||0;
  const recovered = Math.round(orders * reduction / 100);
  $('ordersRecovered').textContent = recovered.toLocaleString('en-IN');
  $('recoveredGmv').textContent = '₹' + ((recovered*aov)/100000).toFixed(2) + 'L';
  $('ticketsAvoided').textContent = Math.round(tickets*ticketReduction/100).toLocaleString('en-IN');
  $('cancelRateLabel').textContent = cancel+'%';
  $('reductionLabel').textContent = reduction.toFixed(1)+' pp';
  $('aovLabel').textContent = money(aov);
  $('ticketReductionLabel').textContent = ticketReduction+'%';
}
['ordersInput','cancelInput','reductionInput','aovInput','ticketsInput','ticketReductionInput'].forEach(id=>$(id).addEventListener('input',recalcImpact));

renderPriority(); renderInventory(); renderOrders(); renderProducts(); recalcImpact(); updateDashboardMetrics();
