# NOVA TRUST OS — Functional Business Rescue Prototype

## What this solves
NOVA CART's case points to a connected reliability problem: uneven partner inventory updates create availability uncertainty; that uncertainty contributes to cancellations and substitutions, slower delivery experiences and avoidable support work. The prototype focuses on making reliability measurable and actionable before the customer experiences failure.

Case evidence used in the prototype includes: current repeat purchase rate 27%, cancellation rate 11%, average delivery time 37 minutes, 5,900 support tickets/month, 35% of cancellations attributed to product unavailability, and 29% of survey respondents reporting that products shown as available can become unavailable after ordering.

Source: PROMPTWARS / NOVA CART Business Rescue Challenge.

## Product thesis
**Fix trust before buying growth.**

NOVA TRUST OS connects four operating steps:

1. **Inventory Pulse** — store/SKU freshness + confidence.
2. **Order Guard** — order-level cancellation risk and interventions.
3. **Customer Promise** — availability and ETA based on reliability signals.
4. **Impact Model** — translates operational improvement into recovered orders, GMV and support load.

## Functional prototype flow

### Demo path
1. Open `index.html`.
2. On Command Center, click an at-risk order and choose **Inspect**.
3. In Order Guard, use **Verify inventory**, **Suggest substitute**, or **Reroute store**.
4. Open Inventory Pulse and verify a stale SKU.
5. Open Customer Promise, add a product and review the reliability checkout.
6. Open Impact Model and change assumptions to see the recovery calculation.
7. Click **Simulate** in the header to run a full reliability scenario.

## No-build local run
Because this is a dependency-free static prototype, it can be opened directly in a browser.

For a local HTTP server instead:

```bash
python -m http.server 8000
```

Then open `http://localhost:8000` from the project directory.

## Files
- `index.html` — application structure and screens.
- `styles.css` — responsive UI and visual system.
- `app.js` — prototype state, risk scoring, inventory verification, customer flow and impact calculations.

## Important prototype note
This is a front-end functional prototype. Data is intentionally local and deterministic for the competition demo; there is no production backend, authentication, live store API or payment integration.
